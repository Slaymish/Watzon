package vrml.api;

import javax.security.auth.login.LoginException;

import java.util.Random;
import java.util.StringTokenizer;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Bot extends ListenerAdapter {
    public static long startTime;
    Random rand = new Random();

    public static void initialize() throws LoginException {
        String token = "OTkxMjg5MTQwMzMzMjU2NzA0.G_m_Zs.tDmaA0hz1Ea0T8hwBt3IaUc9WrVUAXJlSLtVvc";

        startTime = System.currentTimeMillis();

        JDA jda = JDABuilder.createDefault(token)
            .setActivity(Activity.playing("Use 'watz'"))
            .setStatus(OnlineStatus.ONLINE)
            .addEventListeners(new Bot())
            .build();
    }

    public void onMessageReceived(MessageReceivedEvent event){
        String message = event.getMessage().getContentRaw();
        boolean admin = false;
        message = message.toLowerCase();

        if (message.equals("watz")){
            event.getChannel().sendMessage("Type 'watz help' for a list of commands.").queue();
        }

        if (event.getAuthor().getId() == "688474086573211677"){
            admin = true;
        }
        
        if (event.getAuthor().isBot()){
            return;
        }

        if (message.equals("watz help") || message.equals("watz h") || message.equals("watz ?")){
            EmbedBuilder eb = new EmbedBuilder();
            eb.setTitle("Watz Help");
            eb.setDescription("Here are the commands for Watz");
            eb.addField("watz help", "Shows this message", false);
            eb.addField("watz team <team name>", "Shows the stats for the team", false);
            eb.addField("watz top", "Shows the top ten OCE teams", false);
            eb.addField("watz uptime", "Shows the uptime of the bot", false);

            MessageEmbed embed = eb.build();
            event.getChannel().sendMessageEmbeds(embed).queue();



            // add commands here
        }

        if (message.startsWith("watz team")){
            teamInfo(message, event);
        }

        if (message.equals("watz top")){
            topTeams(event);
        }

        if (message.equals("watz hi") || message.equals("watz hello") || message.equals("watz hey")){
            int hiCount = rand.nextInt(3);

            if (hiCount == 1){
                event.getChannel().sendMessage("Hi " + event.getAuthor().getName() + "!").queue();
            }
            if (hiCount == 2){
                event.getChannel().sendMessage("Hello " + event.getAuthor().getName() + "!").queue();
            }
            if (hiCount == 3){
                event.getChannel().sendMessage("Hello...").queue();
            }
            if (hiCount >= 4){
                event.getChannel().sendMessage("Heyoo").queue();
            }
        }

        if (message.equals("watz uptime")){
            long uptime = (System.currentTimeMillis() - startTime)/1000;
            
            event.getChannel().sendMessage(uptime + " secs").queue();
        }
    }

    public void teamInfo(String message, MessageReceivedEvent event){
        StringTokenizer st = new StringTokenizer(message);

            st.nextToken();
            st.nextToken();
            boolean found = false;
            String team = "";
            while (st.hasMoreTokens()){
                String token = st.nextToken();
                team = team + " " + token;
            }


            if (team != ""){
                team = team.substring(1);
                for (Team t: App.OCETeams){
                    if (t.teamName.toLowerCase().equals(team)){
                        found = true;
                        this.embedTeam(t, event);
                    }
                }

                if (!found) {
                    event.getChannel().sendMessage("Team not found").queue();
                }
            }
            else {
                event.getChannel().sendMessage("No team specified").queue();
            }


    }

    public void embedTeam(Team t, MessageReceivedEvent event){
        // Display results
        String url = "https://vrmasterleague.com/EchoArena/Teams/";
        String shortUrl = "https://vrmasterleague.com";
        String teamLogoURL = shortUrl + t.teamLogo;
        String tierURL = shortUrl + t.tierImg;
        url = url + t.teamId;
        url = "[Team Page](" + url + ")";
        EmbedBuilder eb = new EmbedBuilder();
        eb.setTitle(t.teamName);
        eb.setDescription(url);
        eb.setAuthor(t.divisionName, null, tierURL);
        eb.setThumbnail(teamLogoURL);
        eb.addField("Rank", t.teamRank + "", true);

        if (t.active){
            eb.addField("Active", "Yes", true);
        }
        else {
            eb.addField("Active", "No", true);
        }


        eb.addField("MMR", t.teamMMR + "", true);

    
        MessageEmbed embed2 = eb.build();
        event.getChannel().sendMessageEmbeds(embed2).queue();
    }

    public void topTeams(MessageReceivedEvent event){
        String[] teams = App.getTopTeams(App.OCETeams);
        String msg = "";
        EmbedBuilder em = new EmbedBuilder();
        em.setTitle("Top ten OCE teams");
        for (int i = 0; i < teams.length; i++){
            msg = (i+1) + ":  " + teams[i];
            em.addField(msg, "", false);
            
        }

        MessageEmbed embed = em.build();
        event.getChannel().sendMessageEmbeds(embed).queue();

    }
}
