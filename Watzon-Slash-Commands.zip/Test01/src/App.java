import java.net.URL;
import java.net.URLConnection;

// import api requests
    

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        String url = "https://api.vrmasterleague.com/EchoArena/Players";
        
        URLConnection connection = new URL(url).openConnection();


        Unirest.get(url)


    }
}
