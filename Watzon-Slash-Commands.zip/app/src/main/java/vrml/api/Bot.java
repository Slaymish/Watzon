package vrml.api;

import javax.security.auth.login.LoginException;

import org.json.simple.parser.ParseException;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.entities.VoiceChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.SelectMenuInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.InteractionHook;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.requests.restaction.CommandListUpdateAction;
import static net.dv8tion.jda.api.interactions.commands.OptionType.*;
import static org.junit.Assert.assertEquals;

import java.util.EnumSet;

public class Bot extends ListenerAdapter {
    public static long startTime;
    Random rand = new Random();
    static EmbedBuilder helpEmbed = new EmbedBuilder();
    static EmbedBuilder teamEmbed = new EmbedBuilder();


    private static final String TOKEN = "";
    private static final String APP_ID = "12345654321";
    private static final Color WATZ_COL = new Color(30,203,225);

    public static void initialize() throws LoginException, InterruptedException {
        // Get token from file

        startTime = System.currentTimeMillis();

        JDA jda = JDABuilder.createDefault(TOKEN)
            .setActivity(Activity.playing("Use 'watz'"))
            .setStatus(OnlineStatus.ONLINE)
            .addEventListeners(new Bot())
            .build();

        jda.awaitReady();

        
        Guild scrimOrg = jda.getGuildById("810205195941838908");

        // Delete all commands
        scrimOrg.updateCommands().queue();

            scrimOrg.updateCommands()
                .addCommands(Commands.slash("test", "to test slash commands"))
                .addCommands(Commands.slash("help", "Information about the bot"))
                .addCommands(Commands.slash("top", "View the top 10 teams"))
                .addCommands(Commands.slash("size", "View the size of OCE"))
                .addCommands(Commands.slash("team", "Information about a team")
                .addOption(OptionType.STRING, "name", "What team would you like to know about?", true))
                  .queue();

        
        /* 
        CommandListUpdateAction commands = jda.updateCommands();
        commands.addCommands(
            Commands.slash("test", "to test slash commands")
        );
        commands.addCommands(
            Commands.slash("help", "Information about the bot")
        );
        commands.addCommands(
            Commands.slash("team", "Information about a team")
            .addOptions(new OptionData(STRING, "Team Name", "What team would you like to know about?").setRequired(true))
        );

        commands.queue();
        */

        // Set list to 2 commands

        helpEmbed.setTitle("Watz Help");
        helpEmbed.setDescription("Here are the commands for Watz");
        helpEmbed.addField("/help", "Shows this message", false);
        helpEmbed.addField("/team <team name>", "Shows the stats for the team", false);
        helpEmbed.addField("/top", "Shows the top ten OCE teams", false);
        helpEmbed.addField("/size", "Shows no. of active OCE teams", false);
        helpEmbed.addField("/matches WIP", "Shows all upcoming matches", false);
        helpEmbed.addField("/match <match number> WIP", "Shows details about a match (use /matches to see numbers)", false);
        helpEmbed.addField("/player <player name> WIP", "Shows the players VRML stats", false);

        helpEmbed.setColor(WATZ_COL);


    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event){

        switch (event.getName()){
            case "help":
                event.replyEmbeds(helpEmbed.build()).setEphemeral(false) // Ephemeral means only sender can see
                .queue();
                break;
            case "team":
                String teamName = event.getOption("name").getAsString();
                try {
                    event.replyEmbeds(teamInfo(teamName, event).build()).setEphemeral(false) // Ephemeral means only sender can see
                    .queue();
                } catch (ParseException e) {
                    event.reply("An error occurred while parsing the team info").setEphemeral(true).queue(); // Ephemeral means only sender can see
                    e.printStackTrace();
                }

                teamEmbed.clear();
                break;
            case "top":
                event.replyEmbeds(topTeams(event).build()).setEphemeral(false) // Ephemeral means only sender can see
                .queue();
                break;

            case "size":
                event.reply("OCE currently has " + App.activeTeams(App.OCETeams)[0] + " active teams! (" + App.activeTeams(App.OCETeams)[1] + " total teams)").setEphemeral(false) // Ephemeral means only sender can see
                .queue();
                break;

            default:
                event.reply("Unknown command").setEphemeral(false).queue(); // Ephemeral means only sender can see
                break;
        }
    }


    /* 
    public void onMessageReceived(MessageReceivedEvent event){
        String message = event.getMessage().getContentRaw();
        boolean admin = false;
        message = message.toLowerCase();
        System.out.println("Name: " + event.getAuthor().getName() + "  -  " + message);

        if (message.equals("watz")){
            event.getChannel().sendTyping();
            event.getChannel().sendMessage("Type 'watz help' for a list of commands.").queue();
            
            return;
        }

        if (event.getAuthor().getId() == "688474086573211677"){
            admin = true;
        }
        
        if (event.getAuthor().isBot()){
            return;
        }


        if (message.startsWith("watz vc")){
            this.vcChat(message, event);
            return;
        }

        if (message.equals("watz im gonna do it") || message.equals("watz i'm gonna do it")){
            event.getChannel().sendMessage("Please do").queue();
            return;
        }

        if (message.equals("watz top")){
            topTeams(event);
            return;
        }

        if (message.equals("watz hi") || message.equals("watz hello") || message.equals("watz hey")){
            int hiCount = rand.nextInt(3);

            if (hiCount == 1){
                event.getChannel().sendMessage("https://tenor.com/view/omori-basil-kiss-gay-gif-25386247").queue();
            }
            if (hiCount == 2){
                event.getChannel().sendMessage("Hello " + event.getAuthor().getName() + "!").queue();
            }
            if (hiCount == 3){
                event.getChannel().sendMessage("Hello...").queue();
            }
            if (hiCount >= 4){
                event.getChannel().sendMessage("Heyoo").queue();
            }



            return;
        }

        if (message.equals("watz uptime")){
            long uptime = (System.currentTimeMillis() - startTime)/1000;
            
            event.getChannel().sendMessage(uptime + " secs").queue();
            return;
        }
    
        if (message.equals("watz oce size")){
            event.getChannel().sendMessage("OCE currently has " + App.activeTeams(App.OCETeams)[0] + " active teams! (" + App.activeTeams(App.OCETeams)[1] + " total teams)").queue();
            return;
        }

        if (message.equals("watz up")){
            event.getChannel().sendMessage("Nothin much watz up with you?").queue();
            return;
        }

        if (message.startsWith("watz")){
            event.getChannel().sendMessage("I'm not sure how to respond to that.").queue();
            return;
        }
    
    }
    */

    public void vcChat(String message, MessageReceivedEvent event) {
        StringTokenizer st = new StringTokenizer(message);

            st.nextToken();
            st.nextToken();
            boolean found = false;
            String msg = "";
            while (st.hasMoreTokens()){
                String token = st.nextToken();
                msg = msg + " " + token;
            }

            ArrayList<String> vcChats;


            if (msg != ""){
                event.getChannel().sendMessage("VC: " + msg).queue();
                for (String id: getUsersInVoiceChannel(event)){
                    event.getChannel().sendMessage("<@" + id + ">").queue();
                } 
            }
            else {
                event.getChannel().sendMessage("Please specify a messsage").queue();
                return;
            }
    }

    public String[] getUsersInVoiceChannel(MessageReceivedEvent event) {
        ArrayList<String> userList = new ArrayList<>();

        

        for (VoiceChannel vc : event.getGuild().getVoiceChannels()){
            for (Member m : vc.getMembers()){
                userList.add(m.getUser().getId());
            }
        }

        String[] userArray = new String[userList.size()];
        userArray = userList.toArray(userArray);
        return userArray;
      }

    public EmbedBuilder teamInfo(String team, SlashCommandInteractionEvent event) throws ParseException{
        for (Team t: App.OCETeams){
            if (t.teamName.toLowerCase().equals(team)){
                return this.embedTeam(t, event);
            }
        }

        teamEmbed.setTitle("Team not found");
        teamEmbed.setDescription("Please try again");
        teamEmbed.setColor(Color.red);
        return teamEmbed;
    }

    public EmbedBuilder embedTeam(Team t, SlashCommandInteractionEvent event) throws ParseException{                
        // Display results
        String url = "https://vrmasterleague.com/EchoArena/Teams/";
        String shortUrl = "https://vrmasterleague.com";
        String teamLogoURL = shortUrl + t.teamLogo;
        String tierURL = shortUrl + t.tierImg;
        url = url + t.teamId;
        url = "[Team Page](" + url + ")";
        teamEmbed.setTitle(t.teamName);
        teamEmbed.setDescription(url);
        //eb.setAuthor(t.divisionName, null, """";);
        teamEmbed.setThumbnail(tierURL);
        teamEmbed.setImage(teamLogoURL);
        teamEmbed.addField("Rank", t.teamRank + "", true);

        if (t.active){
            teamEmbed.addField("Active", "Yes", true);
        }
        else {
            teamEmbed.addField("Active", "No", true);
        }


        teamEmbed.addField("MMR", t.teamMMR + "", true);
        teamEmbed.setColor(WATZ_COL);



        //eb.addField("Captain", "<@" + captain.discordID + ">", false);
        /* 
        SelectMenu menu;
        menu = SelectMenu.create("menu:class")
        .setRequiredRange(1, 1) // only one can be selected
        .addOption("Team Stats", "teamStats")
        .addOption("Roster", "players")
        .addOption("Upcoming matches", "matches")
        
        .build();
        */

        return teamEmbed;

    }

    public EmbedBuilder topTeams(SlashCommandInteractionEvent event){
        String[] teams = App.getTopTeams(App.OCETeams);
        String msg = "";
        EmbedBuilder em = new EmbedBuilder();
        em.setTitle("Top ten OCE teams");
        for (int i = 0; i < teams.length; i++){
            msg = (i+1) + ":  " + teams[i];
            em.addField(msg, "", false);
            
        }

        em.setColor(WATZ_COL);

        return em;

    }

}
